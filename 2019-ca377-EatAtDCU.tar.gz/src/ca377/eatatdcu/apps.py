from django.apps import AppConfig


class EatatdcuConfig(AppConfig):
    name = 'eatatdcu'
